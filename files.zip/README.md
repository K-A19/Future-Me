# Game UI Navigation System

Welcome to the town game! This project includes a homepage with clickable navigation to four different locations.

## 📁 Project Structure

```
/
├── index.html              # Main homepage with interactive map
├── pages/                  # Subpages directory
│   ├── home.html          # Home location page
│   ├── grocery.html       # Grocery store location page
│   ├── office.html        # Office location page
│   └── school.html        # School location page
└── README.md              # This file
```

## 🎮 How It Works

### Homepage (index.html)
- Displays an interactive town map
- Four clickable areas overlay the map image
- Hover over locations to see labels
- Click any location to navigate to its subpage

### Subpages (pages/*.html)
Each location has its own dedicated HTML file where you can add:
- Game mechanics
- Interactive elements
- Mini-games
- Character interactions
- Location-specific features

## 👥 Team Collaboration Guide

### Assigning Work
Each teammate can work on a different location:
- **Teammate 1**: `pages/home.html` - Home location features
- **Teammate 2**: `pages/grocery.html` - Grocery store mechanics
- **Teammate 3**: `pages/office.html` - Office gameplay
- **Teammate 4**: `pages/school.html` - School activities

### Working on Your Page
1. Open your assigned HTML file
2. Look for the "GAME CONTENT AREA" section
3. Replace the placeholder with your game content
4. Add JavaScript in the `<script>` section at the bottom
5. Test by opening `index.html` in a browser

### Adding Features
Each subpage includes:
- ✅ Background styling (unique gradient per location)
- ✅ Back button to return to homepage
- ✅ Location image display
- ✅ Description section
- ✅ Game content area (for your custom code)
- ✅ JavaScript section (for game logic)

## 🎨 Customization Tips

### Adjusting Button Positions on Homepage
The clickable areas on the map are positioned using percentages. If they don't align perfectly with your map image, edit these CSS classes in `index.html`:

```css
.school-btn { top: 20%; left: 15%; width: 18%; height: 35%; }
.home-btn { bottom: 22%; left: 8%; width: 15%; height: 25%; }
.grocery-btn { top: 18%; right: 25%; width: 20%; height: 28%; }
.office-btn { bottom: 18%; right: 15%; width: 22%; height: 30%; }
```

### Styling Your Subpage
Each subpage has its own color scheme. You can:
- Change the gradient colors in the `body` style
- Modify the back button color
- Adjust the game section styling
- Add new CSS classes for your game elements

## 🚀 Getting Started

1. **Test the navigation**: Open `index.html` in your browser
2. **Pick your location**: Choose which page you'll work on
3. **Start coding**: Add your game mechanics to your assigned file
4. **Share progress**: Each file is independent, so you can work simultaneously

## 💡 Game Mechanic Ideas

### Home
- Inventory management
- Character rest/energy system
- Item storage
- Family interactions

### Grocery Store
- Shopping cart system
- Currency/money management
- Item catalog with prices
- Checkout mini-game

### Office
- Work task mini-games
- Skill progression system
- Meeting/dialogue system
- Career advancement tracking

### School
- Class schedule system
- Quiz/test mechanics
- Knowledge/skill learning
- Social interaction with NPCs

## 🔧 Technical Notes

- All pages use vanilla HTML, CSS, and JavaScript
- No external dependencies required
- Each page is self-contained
- Images are referenced from the uploads directory
- Back buttons use relative paths (`../index.html`)

## 📝 Tips for Success

1. **Test frequently**: Open your page in a browser after each major change
2. **Use console.log()**: Debug your JavaScript in the browser console
3. **Keep it organized**: Comment your code for your teammates
4. **Stay consistent**: Try to maintain similar structure across pages
5. **Communicate**: Let others know when you push major changes

Happy coding! 🎉
